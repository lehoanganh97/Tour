A Pen created at CodePen.io. You can find this one at https://codepen.io/SebKay/pen/lxAwv.

 This is a technique I implemented on my web design blog, Inspirational Pixels (http://inspirationalpixels.com) in the sidebar for the newsletter.